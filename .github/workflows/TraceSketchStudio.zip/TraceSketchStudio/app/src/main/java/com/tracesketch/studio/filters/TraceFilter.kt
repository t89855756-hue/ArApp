package com.tracesketch.studio.filters

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import kotlin.math.roundToInt

enum class TraceFilter {
    NONE,
    GRAYSCALE,
    HIGH_CONTRAST,
    EDGE_DETECTION
}

/**
 * Cheap, real-time filters (grayscale, high-contrast) can run entirely
 * as a Compose ColorMatrix -- GPU-accelerated, no bitmap copy needed.
 * True edge detection requires per-pixel convolution (see
 * [EdgeDetector.toLineArt]) and is applied once to a decoded Bitmap
 * rather than per-frame, since it's a genuine image-processing pass.
 */
fun TraceFilter.toComposeColorFilter(): ColorFilter? = when (this) {
    TraceFilter.NONE -> null

    TraceFilter.GRAYSCALE -> ColorFilter.colorMatrix(
        ColorMatrix().apply { setToSaturation(0f) }
    )

    TraceFilter.HIGH_CONTRAST -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                2.2f, 0f, 0f, 0f, -160f,
                0f, 2.2f, 0f, 0f, -160f,
                0f, 0f, 2.2f, 0f, -160f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    // For EDGE_DETECTION the composable path shows a grayscale preview
    // instantly, while the real Sobel pass runs asynchronously (see
    // EdgeDetector) and swaps in the processed bitmap when ready.
    TraceFilter.EDGE_DETECTION -> ColorFilter.colorMatrix(
        ColorMatrix().apply { setToSaturation(0f) }
    )
}

/**
 * Sobel-operator edge detector producing a black-on-white line-art
 * bitmap suitable for tracing. Runs off the main thread; call from a
 * coroutine (e.g. Dispatchers.Default).
 */
object EdgeDetector {

    fun toLineArt(source: Bitmap, threshold: Int = 60): Bitmap {
        val width = source.width
        val height = source.height
        val gray = IntArray(width * height)
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        for (i in pixels.indices) {
            val p = pixels[i]
            val r = AndroidColor.red(p)
            val g = AndroidColor.green(p)
            val b = AndroidColor.blue(p)
            // Standard luminance-weighted grayscale conversion.
            gray[i] = (0.299 * r + 0.587 * g + 0.114 * b).roundToInt()
        }

        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val outPixels = IntArray(width * height)

        // 3x3 Sobel kernels for horizontal and vertical gradients.
        val gxKernel = intArrayOf(-1, 0, 1, -2, 0, 2, -1, 0, 1)
        val gyKernel = intArrayOf(-1, -2, -1, 0, 0, 0, 1, 2, 1)

        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                var gx = 0
                var gy = 0
                var k = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val sample = gray[(y + dy) * width + (x + dx)]
                        gx += sample * gxKernel[k]
                        gy += sample * gyKernel[k]
                        k++
                    }
                }
                val magnitude = kotlin.math.sqrt((gx * gx + gy * gy).toDouble()).toInt()
                // Invert so edges are black on a white background --
                // matches how a printed reference line-art sheet looks.
                val value = if (magnitude > threshold) 0 else 255
                outPixels[y * width + x] = AndroidColor.rgb(value, value, value)
            }
        }

        output.setPixels(outPixels, 0, width, 0, 0, width, height)
        return output
    }
}
