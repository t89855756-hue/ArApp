package com.tracesketch.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tracesketch.studio.filters.TraceFilter

/**
 * Translucent, horizontally scrollable pill toolbar. Auto-hides via the
 * caller's AnimatedVisibility; this composable only renders the controls.
 */
@Composable
fun FloatingToolbar(
    mode: TracingMode,
    onModeToggle: () -> Unit,
    torchOn: Boolean,
    onTorchToggle: () -> Unit,
    onCameraFlip: () -> Unit,
    locked: Boolean,
    onLockToggle: () -> Unit,
    onGalleryPick: () -> Unit,
    onCapturePhoto: () -> Unit,
    activeFilter: TraceFilter,
    onFilterSelected: (TraceFilter) -> Unit,
    showGrid: Boolean,
    onGridToggle: () -> Unit,
    gridDivisions: Int,
    onGridDivisionsChange: (Int) -> Unit,
    onFlipHorizontal: () -> Unit,
    onFlipVertical: () -> Unit,
    onResetPose: () -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(top = 40.dp, start = 12.dp, end = 12.dp)
            .clip(RoundedCornerShape(28.dp)),
        color = Color.Black.copy(alpha = 0.55f)
    ) {
        Row(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ToolbarIconToggle(
                icon = if (mode == TracingMode.AR_CAMERA) Icons.Default.CameraEnhance else Icons.Default.Lightbulb,
                label = if (mode == TracingMode.AR_CAMERA) "AR" else "Lightbox",
                active = mode == TracingMode.AR_CAMERA,
                onClick = onModeToggle
            )

            if (mode == TracingMode.AR_CAMERA) {
                ToolbarIconToggle(
                    icon = if (torchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                    label = "Torch",
                    active = torchOn,
                    onClick = onTorchToggle
                )
                ToolbarIconToggle(
                    icon = Icons.Default.FlipCameraAndroid,
                    label = "Flip Cam",
                    active = false,
                    onClick = onCameraFlip
                )
            }

            ToolbarIconToggle(
                icon = if (locked) Icons.Default.Lock else Icons.Default.LockOpen,
                label = "Lock",
                active = locked,
                onClick = onLockToggle
            )

            ToolbarIconToggle(
                icon = Icons.Default.PhotoLibrary,
                label = "Gallery",
                active = false,
                onClick = onGalleryPick
            )

            ToolbarIconToggle(
                icon = Icons.Default.CameraAlt,
                label = "Capture",
                active = false,
                onClick = onCapturePhoto
            )

            ToolbarIconToggle(
                icon = Icons.Default.FilterBAndW,
                label = "Line Art",
                active = activeFilter == TraceFilter.EDGE_DETECTION,
                onClick = {
                    onFilterSelected(
                        if (activeFilter == TraceFilter.EDGE_DETECTION) TraceFilter.NONE
                        else TraceFilter.EDGE_DETECTION
                    )
                }
            )

            ToolbarIconToggle(
                icon = Icons.Default.GridOn,
                label = "Grid",
                active = showGrid,
                onClick = onGridToggle
            )

            if (showGrid) {
                ToolbarIconToggle(
                    icon = Icons.Default.Apps,
                    label = if (gridDivisions == 3) "3x3" else "4x4",
                    active = false,
                    onClick = { onGridDivisionsChange(if (gridDivisions == 3) 4 else 3) }
                )
            }

            ToolbarIconToggle(
                icon = Icons.Default.Flip,
                label = "Flip H",
                active = false,
                onClick = onFlipHorizontal
            )
            ToolbarIconToggle(
                icon = Icons.Default.SwapVert,
                label = "Flip V",
                active = false,
                onClick = onFlipVertical
            )
            ToolbarIconToggle(
                icon = Icons.Default.RestartAlt,
                label = "Reset",
                active = false,
                onClick = onResetPose
            )
        }
    }
}

@Composable
private fun ToolbarIconToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (active) Color(0xFF4FC3F7) else Color.White
        )
    }
}
