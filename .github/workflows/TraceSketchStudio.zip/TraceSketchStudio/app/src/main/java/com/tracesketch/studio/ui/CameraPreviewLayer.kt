package com.tracesketch.studio.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.tracesketch.studio.camera.CameraController

/** Renders the live camera feed behind the overlay image in AR Tracing Mode. */
@Composable
fun CameraPreviewLayer(controller: CameraController, modifier: Modifier = Modifier) {
    AndroidView(
        factory = { controller.previewView },
        modifier = modifier.fillMaxSize()
    )
}
