package com.tracesketch.studio.camera

import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Wraps CameraX's Preview + ImageCapture use cases, bound to the current
 * lifecycle. Exposes torch control independently of exposure/zoom so the
 * "keep flash on to illuminate paper" feature works as a steady light
 * source rather than a one-shot flash.
 */
class CameraController(
    val previewView: PreviewView,
    private val cameraProvider: ProcessCameraProvider,
    private var camera: androidx.camera.core.Camera,
    private val imageCapture: ImageCapture
) {
    /** True only if the currently bound camera actually has a flash unit. */
    fun hasFlashUnit(): Boolean = camera.cameraInfo.hasFlashUnit()

    /** Keeps the torch continuously on/off -- distinct from single-shot flash. */
    fun setTorch(enabled: Boolean) {
        if (hasFlashUnit()) {
            camera.cameraControl.enableTorch(enabled)
        }
    }

    suspend fun takePhoto(displayName: String): Uri = suspendCancellableCoroutine { cont ->
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/TraceSketchStudio")
        }
        val resolver = previewView.context.contentResolver
        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            resolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(previewView.context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    cont.resume(output.savedUri ?: Uri.EMPTY)
                }
                override fun onError(exc: ImageCaptureException) {
                    cont.resumeWithException(exc)
                }
            }
        )
    }
}

/**
 * Composable that builds, binds, and remembers a [CameraController] tied
 * to the current lifecycle. Rebinds automatically when [useFrontCamera]
 * changes (camera-flip control in the toolbar).
 */
@Composable
fun rememberCameraController(useFrontCamera: Boolean): CameraController? {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var controller by remember { mutableStateOf<CameraController?>(null) }

    val previewView = remember { PreviewView(context) }

    DisposableEffect(useFrontCamera) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            val selector = if (useFrontCamera) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            cameraProvider.unbindAll()
            val camera = cameraProvider.bindToLifecycle(
                lifecycleOwner, selector, preview, imageCapture
            )

            controller = CameraController(previewView, cameraProvider, camera, imageCapture)
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            controller?.let {
                // Ensure torch is off before unbinding to avoid a stuck LED
                // on some OEM camera HALs.
                it.setTorch(false)
            }
            ProcessCameraProvider.getInstance(context).get().unbindAll()
        }
    }

    return controller
}
