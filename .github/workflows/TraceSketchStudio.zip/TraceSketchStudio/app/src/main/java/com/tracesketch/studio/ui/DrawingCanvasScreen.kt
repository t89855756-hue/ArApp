package com.tracesketch.studio.ui

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.tracesketch.studio.camera.CameraController
import com.tracesketch.studio.camera.rememberCameraController
import com.tracesketch.studio.filters.TraceFilter
import com.tracesketch.studio.filters.toComposeColorFilter
import com.tracesketch.studio.transform.ImageTransformState

/** Which background the overlay image is composited on top of. */
enum class TracingMode { AR_CAMERA, SCREEN_LIGHTBOX }

@Composable
fun DrawingCanvasScreen(
    imageUri: Uri?,
    onPickFromGallery: () -> Unit,
    onCapturePhoto: () -> Unit
) {
    val context = LocalContext.current
    val transformState = remember { ImageTransformState() }

    var mode by remember { mutableStateOf(TracingMode.SCREEN_LIGHTBOX) }
    var activeFilter by remember { mutableStateOf(TraceFilter.NONE) }
    var showGrid by remember { mutableStateOf(false) }
    var gridDivisions by remember { mutableIntStateOf(3) } // 3x3 or 4x4
    var toolbarVisible by remember { mutableStateOf(true) }
    var torchOn by remember { mutableStateOf(false) }
    var usingFrontCamera by remember { mutableStateOf(false) }

    val cameraController: CameraController? =
        if (mode == TracingMode.AR_CAMERA) rememberCameraController(useFrontCamera = usingFrontCamera) else null

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (mode == TracingMode.SCREEN_LIGHTBOX) Color.White else Color.Black)
    ) {
        // --- Background layer: either live camera feed or plain white ---
        if (mode == TracingMode.AR_CAMERA && cameraController != null) {
            CameraPreviewLayer(controller = cameraController)
        }

        // --- Overlay image with pan/zoom/rotate/opacity, gated by lock ---
        if (imageUri != null) {
            AsyncImage(
                model = imageUri,
                contentDescription = "Overlay image to trace",
                contentScale = ContentScale.Fit,
                colorFilter = activeFilter.toComposeColorFilter(),
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(transformState.locked) {
                        if (!transformState.locked) {
                            detectTransformGestures { centroid, pan, zoom, rotation ->
                                transformState.onGesture(centroid, pan, zoom, rotation)
                            }
                        }
                    }
                    .graphicsLayer {
                        translationX = transformState.offset.x
                        translationY = transformState.offset.y
                        scaleX = transformState.scaleX
                        scaleY = transformState.scaleY
                        rotationZ = transformState.rotationDegrees
                        alpha = transformState.opacity
                    }
            )
        } else {
            EmptyStatePrompt(
                onPickFromGallery = onPickFromGallery,
                onCapturePhoto = onCapturePhoto
            )
        }

        // --- Grid overlay, drawn above the image, unaffected by transform ---
        if (showGrid) {
            GridOverlay(divisions = gridDivisions, modifier = Modifier.fillMaxSize())
        }

        // --- Tap empty space to toggle toolbar visibility while tracing ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGesturesToggleToolbar { toolbarVisible = !toolbarVisible }
                }
        )

        AnimatedVisibility(
            visible = toolbarVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            FloatingToolbar(
                mode = mode,
                onModeToggle = {
                    mode = if (mode == TracingMode.AR_CAMERA) TracingMode.SCREEN_LIGHTBOX
                    else TracingMode.AR_CAMERA
                },
                torchOn = torchOn,
                onTorchToggle = {
                    torchOn = !torchOn
                    cameraController?.setTorch(torchOn)
                },
                onCameraFlip = {
                    usingFrontCamera = !usingFrontCamera
                    torchOn = false // front cameras generally lack flash
                },
                locked = transformState.locked,
                onLockToggle = { transformState.toggleLock() },
                onGalleryPick = onPickFromGallery,
                onCapturePhoto = onCapturePhoto,
                activeFilter = activeFilter,
                onFilterSelected = { activeFilter = it },
                showGrid = showGrid,
                onGridToggle = { showGrid = !showGrid },
                gridDivisions = gridDivisions,
                onGridDivisionsChange = { gridDivisions = it },
                onFlipHorizontal = { transformState.flipHorizontal() },
                onFlipVertical = { transformState.flipVertical() },
                onResetPose = { transformState.resetPose() }
            )
        }

        AnimatedVisibility(
            visible = toolbarVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            OpacityBottomSheet(
                opacity = transformState.opacity,
                onOpacityChange = { transformState.setOpacity(it) }
            )
        }
    }
}

@Composable
private fun EmptyStatePrompt(
    onPickFromGallery: () -> Unit,
    onCapturePhoto: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Load an image to start tracing", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onPickFromGallery) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Gallery")
            }
            Button(onClick = onCapturePhoto) {
                Icon(Icons.Default.CameraAlt, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Camera")
            }
        }
    }
}

@Composable
private fun OpacityBottomSheet(
    opacity: Float,
    onOpacityChange: (Float) -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(16.dp)
            .clip(RoundedCornerShape(20.dp)),
        color = Color.Black.copy(alpha = 0.55f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            Text(
                text = "Opacity  ${(opacity * 100).toInt()}%",
                color = Color.White,
                style = MaterialTheme.typography.labelLarge
            )
            Slider(
                value = opacity,
                onValueChange = onOpacityChange,
                valueRange = 0f..1f
            )
        }
    }
}
