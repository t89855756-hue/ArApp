package com.tracesketch.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope

/**
 * Draws a proportion guide grid (3x3 "rule of thirds" or 4x4) above the
 * image. Purely visual -- does not intercept touch, so gestures still
 * reach the image layer beneath it.
 */
@Composable
fun GridOverlay(divisions: Int, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val stepX = size.width / divisions
        val stepY = size.height / divisions
        val lineColor = Color.White.copy(alpha = 0.6f)
        val strokeWidth = 1.5f

        for (i in 1 until divisions) {
            drawLine(
                color = lineColor,
                start = androidx.compose.ui.geometry.Offset(stepX * i, 0f),
                end = androidx.compose.ui.geometry.Offset(stepX * i, size.height),
                strokeWidth = strokeWidth
            )
            drawLine(
                color = lineColor,
                start = androidx.compose.ui.geometry.Offset(0f, stepY * i),
                end = androidx.compose.ui.geometry.Offset(size.width, stepY * i),
                strokeWidth = strokeWidth
            )
        }
    }
}

/**
 * Lightweight single-tap detector used to auto-hide/show the floating
 * toolbar. Runs on Initial pass at low priority so it never steals the
 * touch stream from the image's transform gestures.
 */
suspend fun PointerInputScope.detectTapGesturesToggleToolbar(onTap: () -> Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(pass = PointerEventPass.Final)
        val up = waitForUpOrCancellation(pass = PointerEventPass.Final)
        if (up != null) {
            onTap()
        }
    }
}
