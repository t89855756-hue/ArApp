# Trace & Sketch Studio — Architecture Blueprint

## Module map

```
app/src/main/
├── AndroidManifest.xml              # permissions, FileProvider
├── java/com/tracesketch/studio/
│   ├── MainActivity.kt              # permission flow, image pickers, hosts the screen
│   ├── ui/
│   │   ├── DrawingCanvasScreen.kt   # main screen: composes camera/lightbox + overlay
│   │   ├── FloatingToolbar.kt       # translucent auto-hide toolbar
│   │   ├── CameraPreviewLayer.kt    # AndroidView wrapper around PreviewView
│   │   └── GridOverlay.kt           # 3x3 / 4x4 proportion grid + tap-to-hide gesture
│   ├── transform/
│   │   └── ImageTransformState.kt   # pan/zoom/rotate/opacity/mirror/lock state machine
│   ├── camera/
│   │   └── CameraController.kt      # CameraX binding, torch control, photo capture
│   └── filters/
│       └── TraceFilter.kt           # ColorMatrix filters + Sobel edge-detection
└── res/xml/file_paths.xml           # FileProvider paths for camera capture
```

## How the pieces fit together

**DrawingCanvasScreen** is the composition root for tracing. It owns three
pieces of state: the current `TracingMode` (AR camera vs. white lightbox),
the `ImageTransformState` (all gesture-driven transform values), and the
`TraceFilter` currently applied. Everything else — toolbar, grid, camera
preview — is a child composable driven by that state.

**ImageTransformState** is the core of "multi-touch support." A single
`detectTransformGestures` block on the image's `pointerInput` feeds pan,
zoom, and rotation deltas into `onGesture()`, which rotates the existing
offset around the gesture centroid before adding the new pan — this is
what makes pinch-zoom and twist feel like they pivot under your fingers
instead of around the image's corner. `Modifier.graphicsLayer` reads
`offset`, `scaleX/scaleY` (negative for mirroring), `rotationDegrees`, and
`opacity` directly every frame, so there's no extra recomposition cost per
gesture tick.

**Touch Lock** is implemented by keying the `pointerInput` block on
`transformState.locked`: when true, the gesture detector is never
installed, so all touches pass through to the paper/screen beneath
untouched (Compose still lets taps through since no pointer input consumes
them).

**CameraController** wraps CameraX's `Preview` + `ImageCapture` use cases.
Torch is controlled via `CameraControl.enableTorch()` rather than the
flash mode on `ImageCapture`, because the spec calls for a *continuous*
light source to illuminate paper, not a one-shot capture flash. The
controller rebinds automatically when the front/back selector changes.

**TraceFilter** splits cheap and expensive filtering:
- Grayscale / high-contrast run as a `ColorMatrix` `ColorFilter`, applied
  directly in `Image()`/`AsyncImage()` — free, GPU-composited, real-time.
- True edge detection needs per-pixel convolution (Sobel operator), so
  `EdgeDetector.toLineArt()` runs once on a decoded `Bitmap` on a
  background dispatcher and produces a standalone line-art image, while
  the UI shows an instant grayscale preview so the toggle never feels
  laggy.

## Suggested next steps for your GitHub Actions workflow

1. Add the CameraX, Compose BOM, and Coil dependencies from
   `app/build.gradle.kts` to your existing workflow's dependency cache key
   so builds stay fast.
2. Because `minSdk = 26`, no `Build.VERSION.SDK_INT` gating is needed for
   `graphicsLayer` scale/rotation — it's available since API 21 — but
   `PickVisualMedia` gracefully degrades to the system picker on devices
   below API 33 without you needing to branch on version.
3. If you want the Sobel edge-detection to run at interactive frame rates
   on an actual camera feed later (rather than a captured still), that's
   a good candidate for a `RenderScript`-replacement or
   `androidx.graphics.shapes`/GPU shader pass — happy to sketch that out
   as a follow-up once the still-image version is working end-to-end.
