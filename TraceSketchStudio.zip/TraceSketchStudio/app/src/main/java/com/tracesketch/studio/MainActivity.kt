package com.tracesketch.studio

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.tracesketch.studio.transform.ImageTransformState
import com.tracesketch.studio.ui.DrawingCanvasScreen

private const val PREFS_NAME = "trace_sketch_state"
private const val KEY_IMAGE_URI = "image_uri"
private const val KEY_OFFSET_X = "offset_x"
private const val KEY_OFFSET_Y = "offset_y"
private const val KEY_SCALE = "scale"
private const val KEY_ROTATION = "rotation"
private const val KEY_OPACITY = "opacity"
private const val KEY_MIRROR_H = "mirror_h"
private const val KEY_MIRROR_V = "mirror_v"
private const val KEY_LOCKED = "locked"

class MainActivity : ComponentActivity() {

    private var selectedImageUri by mutableStateOf<Uri?>(null)

    // Hoisted so it survives leaving the app (see onStop/restoreSavedState)
    // rather than being lost when the composable holding it is torn down.
    private val transformState = ImageTransformState()

    // Photo Picker -- no READ_MEDIA_IMAGES permission dialog required on
    // Android 13+, falls back gracefully via the system picker contract.
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let { selectedImageUri = it } }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchGalleryOrCameraFlow(fromCamera = true)
    }

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) selectedImageUri = pendingCameraUri
    }

    private var pendingCameraUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreSavedState()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DrawingCanvasScreen(
                        imageUri = selectedImageUri,
                        transformState = transformState,
                        onPickFromGallery = {
                            galleryLauncher.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        onCapturePhoto = { requestCameraPermissionThenCapture() }
                    )
                }
            }
        }
    }

    private fun requestCameraPermissionThenCapture() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            launchGalleryOrCameraFlow(fromCamera = true)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchGalleryOrCameraFlow(fromCamera: Boolean) {
        if (fromCamera) {
            val photoFile = java.io.File(
                cacheDir, "trace_capture_${System.currentTimeMillis()}.jpg"
            )
            val uri = androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.fileprovider", photoFile
            )
            pendingCameraUri = uri
            takePictureLauncher.launch(uri)
        }
    }

    // --- Persistence: save whenever the app leaves the foreground, so the
    // loaded image and its pose/opacity/lock survive being backgrounded,
    // rotated away from, or killed by the system. ---

    override fun onStop() {
        super.onStop()
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        prefs.edit().apply {
            putString(KEY_IMAGE_URI, selectedImageUri?.toString())
            putFloat(KEY_OFFSET_X, transformState.offset.x)
            putFloat(KEY_OFFSET_Y, transformState.offset.y)
            putFloat(KEY_SCALE, transformState.scale)
            putFloat(KEY_ROTATION, transformState.rotationDegrees)
            putFloat(KEY_OPACITY, transformState.opacityValue)
            putBoolean(KEY_MIRROR_H, transformState.mirroredHorizontal)
            putBoolean(KEY_MIRROR_V, transformState.mirroredVertical)
            putBoolean(KEY_LOCKED, transformState.locked)
            apply()
        }
    }

    private fun restoreSavedState() {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        prefs.getString(KEY_IMAGE_URI, null)?.let { uriString ->
            selectedImageUri = Uri.parse(uriString)
        }
        transformState.restoreState(
            offsetX = prefs.getFloat(KEY_OFFSET_X, 0f),
            offsetY = prefs.getFloat(KEY_OFFSET_Y, 0f),
            scaleValue = prefs.getFloat(KEY_SCALE, 1f),
            rotation = prefs.getFloat(KEY_ROTATION, 0f),
            opacity = prefs.getFloat(KEY_OPACITY, 1f),
            mirrorH = prefs.getBoolean(KEY_MIRROR_H, false),
            mirrorV = prefs.getBoolean(KEY_MIRROR_V, false),
            lockedValue = prefs.getBoolean(KEY_LOCKED, false)
        )
    }
}
