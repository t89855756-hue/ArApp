package com.tracesketch.studio.transform

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Holds all live transform values for the overlay image: pan (offset),
 * scale (pinch-zoom), rotation (two-finger twist), opacity, and mirror
 * flags. Designed to be driven by Compose's detectTransformGestures
 * and consumed directly by Modifier.graphicsLayer.
 *
 * When [locked] is true, gesture deltas are ignored entirely -- this
 * backs the "Touch Lock" feature so paper can be laid on the screen
 * without nudging the image.
 */
class ImageTransformState(
    minScale: Float = 0.2f,
    maxScale: Float = 8f
) {
    var offset by mutableStateOf(Offset.Zero)
        private set
    var scale by mutableFloatStateOf(1f)
        private set
    var rotationDegrees by mutableFloatStateOf(0f)
        private set
    var opacityValue by mutableFloatStateOf(1f) // 0f..1f
        private set
    var mirroredHorizontal by mutableStateOf(false)
        private set
    var mirroredVertical by mutableStateOf(false)
        private set
    var locked by mutableStateOf(false)

    private val minScale = minScale
    private val maxScale = maxScale

    /**
     * Applies a single gesture frame. [centroid] is the pointer centroid
     * in the *current* frame, used so rotation/scale pivot around the
     * user's fingers rather than the composable's origin.
     */
    fun onGesture(centroid: Offset, panDelta: Offset, zoomDelta: Float, rotationDelta: Float) {
        if (locked) return

        val newScale = (scale * zoomDelta).coerceIn(minScale, maxScale)

        // Rotate the existing offset by the incremental rotation and
        // rescale it, so zoom/rotate pivot around the gesture centroid
        // instead of the image's top-left corner.
        val rad = rotationDelta * PI.toFloat() / 180f
        val cosR = cos(rad)
        val sinR = sin(rad)

        val adjustedOffset = Offset(
            x = (offset.x - centroid.x) * cosR - (offset.y - centroid.y) * sinR + centroid.x,
            y = (offset.x - centroid.x) * sinR + (offset.y - centroid.y) * cosR + centroid.y
        )

        offset = adjustedOffset + panDelta
        scale = newScale
        rotationDegrees += rotationDelta
    }

    fun setOpacity(value: Float) {
        opacityValue = value.coerceIn(0f, 1f)
    }

    fun toggleLock() {
        locked = !locked
    }

    fun flipHorizontal() {
        mirroredHorizontal = !mirroredHorizontal
    }

    fun flipVertical() {
        mirroredVertical = !mirroredVertical
    }

    /** Resets pan/zoom/rotate to identity; keeps opacity and flips as-is. */
    fun resetPose() {
        offset = Offset.Zero
        scale = 1f
        rotationDegrees = 0f
    }

    /** Full reset including flips and opacity, e.g. when a new image is loaded. */
    fun resetAll() {
        resetPose()
        opacityValue = 1f
        mirroredHorizontal = false
        mirroredVertical = false
        locked = false
    }

    /** Scale factors to feed into graphicsLayer for mirroring. */
    val scaleX: Float get() = scale * if (mirroredHorizontal) -1f else 1f
    val scaleY: Float get() = scale * if (mirroredVertical) -1f else 1f
}
